// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'https://api-agendamento-go-production.up.railway.app/api',
};
